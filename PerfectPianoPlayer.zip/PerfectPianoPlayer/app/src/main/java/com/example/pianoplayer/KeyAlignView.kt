package com.example.pianoplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * 全螢幕對齊畫面：在 88 個琴鍵上畫出編號圓點，拖動藍色手柄讓圓點對準遊戲裡的琴鍵。
 *  - 左 / 右手柄：調整最左、最右琴鍵的位置（寬度）
 *  - 中間手柄：整體上下左右移動
 *  - 黑 / 白手柄：分別上下調整黑鍵、白鍵的按壓高度
 *  - 雙指捏合：整體縮放寬度
 */
class KeyAlignView(
    ctx: Context,
    private val calib: Calibration,
    private val onFinish: (Boolean) -> Unit
) : View(ctx) {

    private enum class Handle { NONE, LEFT, RIGHT, MOVE, BLACK_ROW, WHITE_ROW }

    private val dens = ctx.resources.displayMetrics.density
    private fun dp(v: Float): Float = v * dens

    private val backup = floatArrayOf(calib.x1, calib.x2, calib.yW, calib.yB)
    private var needFit = !calib.ready
    private var active = Handle.NONE
    private var btn = 0
    private var lastX = 0f
    private var lastY = 0f
    private val loc = IntArray(2)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
        color = 0xFF3D6FD0.toInt()
    }
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Color.BLACK
    }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
    }
    private val whiteLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(4f)
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }

    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val cx = (calib.x1 + calib.x2) / 2f
            val half = ((calib.x2 - calib.x1) / 2f * detector.scaleFactor).coerceAtLeast(dp(120f))
            calib.x1 = cx - half
            calib.x2 = cx + half
            invalidate()
            return true
        }
    })

    // ---------------------------------------------------------------- 手柄位置（螢幕座標）

    private fun midX(): Float = (calib.x1 + calib.x2) / 2f
    private fun pill(cx: Float, cy: Float, w: Float, h: Float) =
        RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)

    private fun pillLeft() = pill(calib.x1, calib.yW, dp(40f), dp(90f))
    private fun pillRight() = pill(calib.x2, calib.yW, dp(40f), dp(90f))
    private fun pillMove() = pill(midX(), calib.yW, dp(90f), dp(40f))
    private fun pillBlack() = pill(calib.x1 + (calib.x2 - calib.x1) * 0.25f, calib.yB, dp(90f), dp(40f))
    private fun pillWhite() = pill(calib.x1 + (calib.x2 - calib.x1) * 0.75f, calib.yW, dp(90f), dp(40f))

    private fun autoFit() {
        getLocationOnScreen(loc)
        val n = (calib.highWhite - calib.lowWhite).coerceAtLeast(1)
        val ww = width / (n + 1f)
        calib.x1 = loc[0] + ww / 2f
        calib.x2 = loc[0] + width - ww / 2f
        calib.yW = loc[1] + height * 0.82f
        calib.yB = loc[1] + height * 0.40f
    }

    private fun grab(sx: Float, sy: Float): Handle {
        val slop = dp(12f)
        fun hit(r: RectF): Boolean =
            RectF(r.left - slop, r.top - slop, r.right + slop, r.bottom + slop).contains(sx, sy)
        return when {
            hit(pillMove()) -> Handle.MOVE
            hit(pillBlack()) -> Handle.BLACK_ROW
            hit(pillWhite()) -> Handle.WHITE_ROW
            hit(pillLeft()) -> Handle.LEFT
            hit(pillRight()) -> Handle.RIGHT
            else -> Handle.NONE
        }
    }

    // 右上角三個按鈕：1=保存 2=取消 3=重置
    private fun buttonAt(vx: Float, vy: Float): Int {
        val cx = width - dp(50f)
        val r2 = dp(30f) * dp(30f)
        for (i in 1..3) {
            val cy = dp(70f) + (i - 1) * dp(70f)
            if ((vx - cx) * (vx - cx) + (vy - cy) * (vy - cy) <= r2) return i
        }
        return 0
    }

    private fun press(i: Int) {
        when (i) {
            1 -> {
                calib.save()
                onFinish(true)
            }
            2 -> {
                calib.x1 = backup[0]
                calib.x2 = backup[1]
                calib.yW = backup[2]
                calib.yB = backup[3]
                onFinish(false)
            }
            3 -> {
                autoFit()
                invalidate()
            }
        }
    }

    // ---------------------------------------------------------------- 觸控

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        if (scaler.isInProgress || e.pointerCount > 1) {
            active = Handle.NONE
            btn = 0
            return true
        }
        getLocationOnScreen(loc)
        val vx = e.rawX - loc[0]
        val vy = e.rawY - loc[1]
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX
                lastY = e.rawY
                btn = buttonAt(vx, vy)
                active = if (btn == 0) grab(e.rawX, e.rawY) else Handle.NONE
            }
            MotionEvent.ACTION_MOVE -> {
                if (active != Handle.NONE) {
                    val dx = e.rawX - lastX
                    val dy = e.rawY - lastY
                    lastX = e.rawX
                    lastY = e.rawY
                    when (active) {
                        Handle.LEFT -> calib.x1 = min(calib.x1 + dx, calib.x2 - dp(120f))
                        Handle.RIGHT -> calib.x2 = max(calib.x2 + dx, calib.x1 + dp(120f))
                        Handle.MOVE -> {
                            calib.x1 += dx
                            calib.x2 += dx
                            calib.yW += dy
                            calib.yB += dy
                        }
                        Handle.BLACK_ROW -> calib.yB += dy
                        Handle.WHITE_ROW -> calib.yW += dy
                        Handle.NONE -> {}
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val b = btn
                active = Handle.NONE
                btn = 0
                if (b != 0 && buttonAt(vx, vy) == b) press(b)
            }
            MotionEvent.ACTION_CANCEL -> {
                active = Handle.NONE
                btn = 0
            }
        }
        return true
    }

    // ---------------------------------------------------------------- 繪製

    private fun drawPill(c: Canvas, r: RectF, ox: Float, oy: Float, label: String) {
        val rr = RectF(r.left - ox, r.top - oy, r.right - ox, r.bottom - oy)
        val radius = min(rr.width(), rr.height()) / 2f
        fill.color = 0xAA6FA3E8.toInt()
        c.drawRoundRect(rr, radius, radius, fill)
        c.drawRoundRect(rr, radius, radius, edge)
        white.textSize = dp(12f)
        c.drawText(label, rr.centerX(), rr.centerY() + dp(4f), white)
    }

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(loc)
        if (needFit) {
            autoFit()
            needFit = false
        }
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        c.drawColor(0x22000000)

        val span = (calib.highWhite - calib.lowWhite).coerceAtLeast(1)
        val r = ((calib.x2 - calib.x1) / span * 0.46f).coerceIn(dp(6f), dp(20f))

        // 先畫白鍵圓點，再畫黑鍵圓點（黑鍵在上層）
        for (pass in 0..1) {
            for (k in 21..108) {
                if (Keys.isBlack(k) != (pass == 1)) continue
                if (calib.resolve(k) != k) continue
                val pt = calib.pointFor(k) ?: continue
                fill.color = if (pass == 1) 0xE6F2A65A.toInt() else 0xE6F4D35E.toInt()
                val cx = pt.first - ox
                val cy = pt.second - oy
                c.drawCircle(cx, cy, r, fill)
                ink.textSize = r * 0.95f
                c.drawText((k - 20).toString(), cx, cy + r * 0.33f, ink)
            }
        }

        drawPill(c, pillLeft(), ox, oy, "左")
        drawPill(c, pillRight(), ox, oy, "右")
        drawPill(c, pillMove(), ox, oy, "移動")
        drawPill(c, pillBlack(), ox, oy, "黑↕")
        drawPill(c, pillWhite(), ox, oy, "白↕")

        // 提示文字
        val hint = "拖動藍色手柄，讓圓點對準琴鍵；雙指可縮放；右上角 ✓ 保存"
        white.textSize = dp(13f)
        val tw = white.measureText(hint)
        val hy = height * 0.22f
        fill.color = 0xAA000000.toInt()
        c.drawRoundRect(
            RectF(width / 2f - tw / 2f - dp(12f), hy - dp(20f), width / 2f + tw / 2f + dp(12f), hy + dp(10f)),
            dp(10f), dp(10f), fill
        )
        c.drawText(hint, width / 2f, hy, white)

        // 右上角按鈕
        val bx = width - dp(50f)
        val br = dp(26f)
        fill.color = 0xFF3D7BE8.toInt()
        c.drawCircle(bx, dp(70f), br, fill)
        val p = Path()
        p.moveTo(bx - dp(11f), dp(70f))
        p.lineTo(bx - dp(3f), dp(79f))
        p.lineTo(bx + dp(12f), dp(60f))
        c.drawPath(p, whiteLine)

        fill.color = 0xFF555566.toInt()
        c.drawCircle(bx, dp(140f), br, fill)
        c.drawLine(bx - dp(9f), dp(131f), bx + dp(9f), dp(149f), whiteLine)
        c.drawLine(bx + dp(9f), dp(131f), bx - dp(9f), dp(149f), whiteLine)

        c.drawCircle(bx, dp(210f), br, fill)
        white.textSize = dp(13f)
        c.drawText("重置", bx, dp(210f) + dp(5f), white)
    }
}
