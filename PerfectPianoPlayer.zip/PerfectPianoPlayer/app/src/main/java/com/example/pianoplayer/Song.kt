package com.example.pianoplayer

import android.content.Context
import java.io.File

class Note(
    val key: Int,            // MIDI 音高 21..108 (A0..C8)
    val startMs: Double,
    val endMs: Double,
    val sustainEndMs: Double, // 若踏板踩著，音符實際延續到踏板放開
    val velocity: Int
)

class Song(val notes: List<Note>, val durationMs: Double)

object SongHolder {
    @Volatile var song: Song? = null
    @Volatile var name: String = ""

    /** 把最近選的 MIDI 存起來，應用被系統回收後可自動讀回 */
    fun remember(ctx: Context, bytes: ByteArray, displayName: String) {
        try {
            File(ctx.filesDir, "last.mid").writeBytes(bytes)
            ctx.getSharedPreferences("song", Context.MODE_PRIVATE)
                .edit().putString("name", displayName).apply()
        } catch (_: Exception) {
        }
    }

    fun restore(ctx: Context) {
        if (song != null) return
        try {
            val f = File(ctx.filesDir, "last.mid")
            if (!f.exists()) return
            song = MidiParser.parse(f.readBytes())
            name = ctx.getSharedPreferences("song", Context.MODE_PRIVATE)
                .getString("name", "MIDI") ?: "MIDI"
        } catch (_: Exception) {
        }
    }
}

object MidiParser {
    private const val TEMPO = 0
    private const val PEDAL = 1
    private const val NOTE_OFF = 2
    private const val NOTE_ON = 3

    private class Ev(val tick: Long, val kind: Int, val ch: Int, val d1: Int, val d2: Int)

    fun parse(data: ByteArray): Song {
        if (data.size < 14 || String(data, 0, 4, Charsets.ISO_8859_1) != "MThd") {
            throw IllegalArgumentException("不是有效的 MIDI 檔案")
        }
        var p = 0
        fun u8(): Int = data[p++].toInt() and 0xFF
        fun u16(): Int { val a = u8(); return (a shl 8) or u8() }
        fun u32(): Int { val a = u16(); return (a shl 16) or u16() }
        fun varLen(): Int {
            var v = 0
            while (true) {
                val b = u8()
                v = (v shl 7) or (b and 0x7F)
                if ((b and 0x80) == 0) break
            }
            return v
        }

        p = 4
        val headerLen = u32()
        u16() // format
        val trackCount = u16()
        val division = u16()
        if ((division and 0x8000) != 0) throw IllegalArgumentException("不支援 SMPTE 時間格式的 MIDI")
        if (division == 0) throw IllegalArgumentException("MIDI 檔案時間解析度無效")
        p = 8 + headerLen

        val events = ArrayList<Ev>()
        for (t in 0 until trackCount) {
            if (p + 8 > data.size) break
            val id = String(data, p, 4, Charsets.ISO_8859_1)
            p += 4
            val len = u32()
            val end = minOf(p + len, data.size)
            if (id != "MTrk") { p = end; continue }
            var tick = 0L
            var running = 0
            while (p < end) {
                tick += varLen().toLong()
                var status = data[p].toInt() and 0xFF
                if (status < 0x80) {
                    status = running
                } else {
                    p++
                    if (status < 0xF0) running = status
                }
                when {
                    status == 0xFF -> {
                        val type = u8()
                        val l = varLen()
                        if (type == 0x51 && l == 3) {
                            val tempo = (u8() shl 16) or (u8() shl 8) or u8()
                            events.add(Ev(tick, TEMPO, 0, tempo, 0))
                        } else {
                            p += l
                        }
                    }
                    status == 0xF0 || status == 0xF7 -> {
                        val l = varLen()
                        p += l
                    }
                    status >= 0x80 -> {
                        val hi = status and 0xF0
                        val ch = status and 0x0F
                        if (hi == 0xC0 || hi == 0xD0) {
                            p += 1
                        } else {
                            val d1 = u8()
                            val d2 = u8()
                            if (hi == 0x90) {
                                events.add(Ev(tick, if (d2 == 0) NOTE_OFF else NOTE_ON, ch, d1, d2))
                            } else if (hi == 0x80) {
                                events.add(Ev(tick, NOTE_OFF, ch, d1, d2))
                            } else if (hi == 0xB0 && d1 == 64) {
                                events.add(Ev(tick, PEDAL, ch, d2, 0))
                            }
                        }
                    }
                    else -> p += 1
                }
            }
            p = end
        }

        events.sortWith(compareBy<Ev>({ it.tick }, { it.kind }))

        var tempo = 500000
        var lastTick = 0L
        var lastMs = 0.0
        val openStart = DoubleArray(16 * 128) { -1.0 }
        val openVel = IntArray(16 * 128)
        val raw = ArrayList<DoubleArray>()
        val pedalIv = ArrayList<DoubleArray>()
        var pedalDown = false
        var pedalMs = 0.0

        fun close(k: Int, endMs: Double) {
            val s = openStart[k]
            if (s < 0) return
            openStart[k] = -1.0
            val key = k % 128
            if (k / 128 != 9 && key in 21..108) {
                raw.add(doubleArrayOf(key.toDouble(), s, maxOf(endMs, s + 20.0), openVel[k].toDouble()))
            }
        }

        for (e in events) {
            val ms = lastMs + (e.tick - lastTick) * tempo.toDouble() / 1000.0 / division
            lastTick = e.tick
            lastMs = ms
            when (e.kind) {
                TEMPO -> tempo = e.d1
                PEDAL -> {
                    if (e.d1 >= 64 && !pedalDown) {
                        pedalDown = true
                        pedalMs = ms
                    } else if (e.d1 < 64 && pedalDown) {
                        pedalDown = false
                        pedalIv.add(doubleArrayOf(pedalMs, ms))
                    }
                }
                NOTE_ON -> {
                    val k = e.ch * 128 + e.d1
                    close(k, ms)
                    openStart[k] = ms
                    openVel[k] = e.d2
                }
                NOTE_OFF -> close(e.ch * 128 + e.d1, ms)
            }
        }
        for (k in openStart.indices) close(k, lastMs)
        if (pedalDown) pedalIv.add(doubleArrayOf(pedalMs, lastMs))

        val sorted = raw.sortedWith(compareBy<DoubleArray>({ it[1] }, { it[0] }))
        val notes = sorted.map { r ->
            Note(r[0].toInt(), r[1], r[2], sustainEnd(r[2], pedalIv), r[3].toInt())
        }
        if (notes.isEmpty()) throw IllegalArgumentException("沒有可彈奏的音符（需在 A0–C8 範圍內）")
        val duration = notes.maxOf { it.endMs }
        return Song(notes, duration)
    }

    private fun sustainEnd(end: Double, iv: List<DoubleArray>): Double {
        var lo = 0
        var hi = iv.size - 1
        var found = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (iv[mid][0] <= end) { found = mid; lo = mid + 1 } else hi = mid - 1
        }
        return if (found >= 0 && iv[found][1] > end) iv[found][1] else end
    }
}
